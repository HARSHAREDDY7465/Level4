PCF Subgrid Component
=====================

What this bundle contains
- TypeScript-based PCF control (src/index.ts)
- Control manifest (ControlManifest.Input.xml)
- Original CSS pulled into styles/oppstylereturns.css (keeps original look)
- README with packaging & deployment instructions

Notes & Limitations
- This conversion preserves core features: inline editing, validation hook, dynamic rows, styling.
- The full original single-file JS is large; this PCF implements the same behaviors using the Dataverse webAPI via context.webAPI.
- Lookup dropdowns use simple search via retrieveMultipleRecords; you may need to adjust fetch limits or add async debounce server-side.

Packaging & Deploying
1. Install Power Platform CLI and tools (pac).
2. Build the project (tsc) and create a solution using the pac tooling or use `pcf-scripts` if desired.
3. Example (manual):
   - Compile TypeScript: `npx tsc`
   - Create control bundle: `pac pcf push --publisher-name <publisher>` (or follow Microsoft docs)
4. Import the solution ZIP to your Dataverse environment and add the control to a model-driven form subgrid field.
