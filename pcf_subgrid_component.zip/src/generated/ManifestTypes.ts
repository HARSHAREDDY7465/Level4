export interface IInputs {
  dataset?: ComponentFramework.PropertyTypes.DataSet;
  contextId?: string;
}
export interface IOutputs {}
